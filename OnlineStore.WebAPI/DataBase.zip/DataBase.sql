USE [master]
GO
/****** Object:  Database [OnlineStore]    Script Date: 2019/09/12 10:57:33 ******/
CREATE DATABASE [OnlineStore]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'OnlineStore', FILENAME = N'c:\Program Files\Microsoft SQL Server\MSSQL11.SQLEXPRESS\MSSQL\DATA\OnlineStore.mdf' , SIZE = 3072KB , MAXSIZE = UNLIMITED, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'OnlineStore_log', FILENAME = N'c:\Program Files\Microsoft SQL Server\MSSQL11.SQLEXPRESS\MSSQL\DATA\OnlineStore_log.ldf' , SIZE = 1024KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO
ALTER DATABASE [OnlineStore] SET COMPATIBILITY_LEVEL = 110
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [OnlineStore].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [OnlineStore] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [OnlineStore] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [OnlineStore] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [OnlineStore] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [OnlineStore] SET ARITHABORT OFF 
GO
ALTER DATABASE [OnlineStore] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [OnlineStore] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [OnlineStore] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [OnlineStore] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [OnlineStore] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [OnlineStore] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [OnlineStore] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [OnlineStore] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [OnlineStore] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [OnlineStore] SET  DISABLE_BROKER 
GO
ALTER DATABASE [OnlineStore] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [OnlineStore] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [OnlineStore] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [OnlineStore] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [OnlineStore] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [OnlineStore] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [OnlineStore] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [OnlineStore] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [OnlineStore] SET  MULTI_USER 
GO
ALTER DATABASE [OnlineStore] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [OnlineStore] SET DB_CHAINING OFF 
GO
ALTER DATABASE [OnlineStore] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [OnlineStore] SET TARGET_RECOVERY_TIME = 0 SECONDS 
GO
USE [OnlineStore]
GO
/****** Object:  Table [dbo].[tblBrands]    Script Date: 2019/09/12 10:57:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblBrands](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Brand_Description] [nvarchar](200) NULL,
 CONSTRAINT [PK_tblBrands] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblCategory]    Script Date: 2019/09/12 10:57:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblCategory](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[CategoryDescription] [nvarchar](200) NULL,
 CONSTRAINT [PK_tblCategory] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblOrders]    Script Date: 2019/09/12 10:57:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblOrders](
	[Id] [int] NOT NULL,
	[OrderNumber] [char](10) NULL,
	[Update_Date] [datetime] NULL,
	[Create_Date] [datetime] NULL,
	[User_Id] [nvarchar](50) NULL,
	[Processed] [bit] NULL,
 CONSTRAINT [PK_tblOrders] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblProduct_Orders]    Script Date: 2019/09/12 10:57:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblProduct_Orders](
	[Id] [int] NOT NULL,
	[Product_Id] [int] NULL,
	[Order_Id] [int] NULL,
 CONSTRAINT [PK_tblProduct_Orders] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblProducts]    Script Date: 2019/09/12 10:57:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblProducts](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Brand_Id] [int] NULL,
	[Category_Id] [int] NULL,
	[Supplier_Id] [int] NULL,
	[Product_Code] [char](10) NULL,
	[Badge] [image] NULL,
	[Stock_Count] [int] NULL,
	[Condition] [varchar](50) NULL,
	[Product_Description] [nvarchar](200) NULL,
	[Price] [money] NULL,
	[Update_Date] [datetime] NULL,
	[User_Id] [varchar](150) NULL,
 CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblServiceLogs]    Script Date: 2019/09/12 10:57:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblServiceLogs](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Message] [nvarchar](max) NULL,
	[MessageTemplate] [nvarchar](max) NULL,
	[Level] [nvarchar](128) NULL,
	[TimeStamp] [datetimeoffset](7) NOT NULL,
	[Exception] [nvarchar](max) NULL,
	[Properties] [xml] NULL,
	[LogEvent] [nvarchar](max) NULL,
 CONSTRAINT [PK_Log] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO
/****** Object:  Table [dbo].[tblSupplier]    Script Date: 2019/09/12 10:57:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[tblSupplier](
	[Id] [int] NOT NULL,
	[Name] [nvarchar](100) NULL,
 CONSTRAINT [PK_tblSupplier] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO
SET IDENTITY_INSERT [dbo].[tblBrands] ON 

GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (1, N'NIKE')
GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (2, N'UNDER ARMOUR')
GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (3, N'ADIDAS')
GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (4, N'PUMA')
GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (5, N'ASICS')
GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (6, N'ACNE')
GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (7, N'GRUNE ERDE')
GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (8, N'ALBIRO')
GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (9, N'RONHILL')
GO
INSERT [dbo].[tblBrands] ([Id], [Brand_Description]) VALUES (10, N'NONE')
GO
SET IDENTITY_INSERT [dbo].[tblBrands] OFF
GO
SET IDENTITY_INSERT [dbo].[tblCategory] ON 

GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (1, N'SPORTWARE')
GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (2, N'MENS')
GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (3, N'WOMENS')
GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (4, N'KIDS')
GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (5, N'FASHION')
GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (6, N'HOUSEHOLDS')
GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (7, N'INTERIORS')
GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (8, N'CLOTHING')
GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (9, N'BAGS')
GO
INSERT [dbo].[tblCategory] ([Id], [CategoryDescription]) VALUES (10, N'SHOES')
GO
SET IDENTITY_INSERT [dbo].[tblCategory] OFF
GO
SET IDENTITY_INSERT [dbo].[tblProducts] ON 

GO
INSERT [dbo].[tblProducts] ([Id], [Brand_Id], [Category_Id], [Supplier_Id], [Product_Code], [Badge], [Stock_Count], [Condition], [Product_Description], [Price], [Update_Date], [User_Id]) VALUES (1, 1, 2, 1, N'xx12      ', 0x6E6F496D616765, 2, N'good', N'description', 400.0000, CAST(N'2019-09-11T19:54:37.007' AS DateTime), N'administrator')
GO
INSERT [dbo].[tblProducts] ([Id], [Brand_Id], [Category_Id], [Supplier_Id], [Product_Code], [Badge], [Stock_Count], [Condition], [Product_Description], [Price], [Update_Date], [User_Id]) VALUES (2, 1, 2, 2, N'xx12      ', 0x6E6F496D616765, 2, N'good', N'description', 500.0000, CAST(N'2019-09-11T20:27:46.280' AS DateTime), N'administrator')
GO
INSERT [dbo].[tblProducts] ([Id], [Brand_Id], [Category_Id], [Supplier_Id], [Product_Code], [Badge], [Stock_Count], [Condition], [Product_Description], [Price], [Update_Date], [User_Id]) VALUES (3, 1, 2, 1, N'PC121     ', 0xD31E84E85E3DE83EB5EBBEB9, 7, N'New', N'2134213', 1322314231.0000, CAST(N'2019-09-12T07:02:23.137' AS DateTime), N'System')
GO
INSERT [dbo].[tblProducts] ([Id], [Brand_Id], [Category_Id], [Supplier_Id], [Product_Code], [Badge], [Stock_Count], [Condition], [Product_Description], [Price], [Update_Date], [User_Id]) VALUES (4, 1, 3, 2, N'PC132     ', 0xD31E84E85E3DE83EB5EBBEB9, 4, N'New', N'wfasfasdfdsda', 2134213.0000, CAST(N'2019-09-12T07:42:59.173' AS DateTime), N'System')
GO
SET IDENTITY_INSERT [dbo].[tblProducts] OFF
GO
INSERT [dbo].[tblSupplier] ([Id], [Name]) VALUES (1, N'supplier1')
GO
INSERT [dbo].[tblSupplier] ([Id], [Name]) VALUES (2, N'supplier2')
GO
ALTER TABLE [dbo].[tblProduct_Orders]  WITH CHECK ADD  CONSTRAINT [FK_tblProduct_Orders_tblOrders] FOREIGN KEY([Order_Id])
REFERENCES [dbo].[tblOrders] ([Id])
GO
ALTER TABLE [dbo].[tblProduct_Orders] CHECK CONSTRAINT [FK_tblProduct_Orders_tblOrders]
GO
ALTER TABLE [dbo].[tblProduct_Orders]  WITH CHECK ADD  CONSTRAINT [FK_tblProduct_Orders_tblProducts] FOREIGN KEY([Product_Id])
REFERENCES [dbo].[tblProducts] ([Id])
GO
ALTER TABLE [dbo].[tblProduct_Orders] CHECK CONSTRAINT [FK_tblProduct_Orders_tblProducts]
GO
ALTER TABLE [dbo].[tblProducts]  WITH CHECK ADD  CONSTRAINT [FK_tblProducts_tblBrands] FOREIGN KEY([Brand_Id])
REFERENCES [dbo].[tblBrands] ([Id])
GO
ALTER TABLE [dbo].[tblProducts] CHECK CONSTRAINT [FK_tblProducts_tblBrands]
GO
ALTER TABLE [dbo].[tblProducts]  WITH CHECK ADD  CONSTRAINT [FK_tblProducts_tblCategory] FOREIGN KEY([Category_Id])
REFERENCES [dbo].[tblCategory] ([Id])
GO
ALTER TABLE [dbo].[tblProducts] CHECK CONSTRAINT [FK_tblProducts_tblCategory]
GO
ALTER TABLE [dbo].[tblProducts]  WITH CHECK ADD  CONSTRAINT [FK_tblProducts_tblSupplier] FOREIGN KEY([Supplier_Id])
REFERENCES [dbo].[tblSupplier] ([Id])
GO
ALTER TABLE [dbo].[tblProducts] CHECK CONSTRAINT [FK_tblProducts_tblSupplier]
GO
/****** Object:  StoredProcedure [dbo].[Usp_GetAllBrands]    Script Date: 2019/09/12 10:57:33 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Usp_GetAllBrands]
AS
BEGIN
        SELECT brand.Id AS Id, brand.Brand_Description AS Brand_Description, COUNT(product.Id) NumberOfProduct
        FROM tblBrands brand
                INNER JOIN tblProducts product ON brand.Id = product.Brand_Id
        GROUP BY brand.Id,brand.Brand_Description
        ORDER BY 3 ASC
END


GO
USE [master]
GO
ALTER DATABASE [OnlineStore] SET  READ_WRITE 
GO
